﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace App.Tests
{
    /// <summary>
    /// Summary description for ValidatorTests
    /// </summary>
    [TestClass]
    public class ValidatorTests
    {
        private Validator _validator;
        public ValidatorTests()
        {
            this._validator = new Validator();
        }


        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void ValidatorReturnsTrueForValidFirstNameAndSurnameExist()
        {
            var customer = new Customer
            {
                Firstname = "Ahmed",
                Surname = "Kaouri",
                EmailAddress = "a@b.com"
            };
            var result = this._validator.ValidateName(customer);

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void ValidatorReturnsFalseIfSurnameNameMissing()
        {
            var customer = new Customer
            {
                Firstname = "Ahmed",
                EmailAddress = "a@b.com"
            };
            var result = this._validator.ValidateName(customer);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void ValidatorReturnsFalseIfFirstNameMissing()
        {
            var customer = new Customer
            {
                Surname = "Kaouri",
                EmailAddress = "a@b.com"
            };
            var result = this._validator.ValidateName(customer);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void ValidatorReturnsTrueForValidEmail()
        {
            var customer = new Customer
            {
                Firstname = "Ahmed",
                Surname = "Kaouri",
                EmailAddress = "a@b.com"
            };
            var result = this._validator.ValidateEmail(customer);

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void ValidatorReturnsFalseForInValidEmailMissingAtSymbol()
        {
            var customer = new Customer
            {
                Firstname = "Ahmed",
                Surname = "Kaouri",
                EmailAddress = "ab.com"
            };
            var result = this._validator.ValidateEmail(customer);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void ValidatorReturnsFalseForInValidEmailMissingDotSymbol()
        {
            var customer = new Customer
            {
                Firstname = "Ahmed",
                Surname = "Kaouri",
                EmailAddress = "a@bcom"
            };
            var result = this._validator.ValidateEmail(customer);

            Assert.IsFalse(result);
        }
    }
}
