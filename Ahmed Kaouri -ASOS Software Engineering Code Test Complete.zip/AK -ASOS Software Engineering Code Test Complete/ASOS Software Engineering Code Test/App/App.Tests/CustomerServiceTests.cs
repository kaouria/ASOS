﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using App.Abstract;

namespace App.Tests
{
    [TestClass]
    public class CustomerServiceTests
    {
        [TestMethod]
        public void CheckValidCustomerIsAddedSuccessfully()
        {
            var repo = new Mock<ICompanyRepository>();
            repo.Setup(m => m.GetById(1)).Returns(new Company() {Id = 1, Name= "VeryImportantClient", Classification = new Classification() } );

            var customerService = new CustomerService(new Validator(), repo.Object);

            var customer = new Customer
            {
                Id = 1,
                Firstname = "Ahmed",
                Surname = "Kaouri",
                EmailAddress = "a@b.com"
            };

            Assert.IsTrue(customerService.AddCustomer(customer, 1));
        }

        [TestMethod]
        public void CheckInValidCustomerIsNotAdded()
        {
            var repo = new Mock<ICompanyRepository>();
            repo.Setup(m => m.GetById(1)).Returns(new Company() { Id = 1, Name = "VeryImportantClient", Classification = new Classification() });

            var customerService = new CustomerService(new Validator(), repo.Object);

            var customer = new Customer
            {
                Id = 1
            };

            Assert.IsFalse(customerService.AddCustomer(customer, 1));
        }

    }
}
