﻿using App.Abstract;
using System;

namespace App
{
    public class Validator : IValidator
    {
        public bool ValidateName(ICustomer customer)
        {
            return !(string.IsNullOrEmpty(customer.Firstname) || string.IsNullOrEmpty(customer.Surname));
        }

        public bool ValidateEmail(ICustomer customer)
        {
            return (customer.EmailAddress.Contains("@") && customer.EmailAddress.Contains("."));
        }

        public bool IsOverTwentyOne(ICustomer customer)
        {
            var now = DateTime.Now;
            int age = now.Year - customer.DateOfBirth.Year;
            if (now.Month < customer.DateOfBirth.Month || (now.Month == customer.DateOfBirth.Month && now.Day < customer.DateOfBirth.Day)) age--;

            return !(age < 21);
        }
    }
}
