﻿using App.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace App
{
    public class CustomerService
    {
        private IValidator _validator;
        private ICompanyRepository _repository;

        public CustomerService(IValidator validator, ICompanyRepository repository)
        {
            this._validator = validator;
            this._repository = repository;
        }


        public bool AddCustomer(ICustomer customer, int companyId)
        {
            try
            {
                this._validator.ValidateName(customer);

                this._validator.ValidateEmail(customer);

                customer.Company = this._repository.GetById(companyId);

                CustomerDataAccess.AddCustomer(customer);

                return true;
            }
            catch (Exception)
            {

                throw;
            }

        }
    }
}
