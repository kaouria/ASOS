﻿using App.Abstract;

namespace App
{
    public interface IValidator
    {
        bool IsOverTwentyOne(ICustomer customer);
        bool ValidateEmail(ICustomer customer);
        bool ValidateName(ICustomer customer);
    }
}