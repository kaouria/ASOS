﻿namespace App.Abstract
{
    public interface ICompanyRepository
    {
        Company GetById(int id);
    }
}